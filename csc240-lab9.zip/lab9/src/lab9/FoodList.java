package lab9;

public class FoodList {

	    private Node head; // Head of the list

	    private class Node {
	        Food food;
	        Node next;

	        public Node(Food food) {
	            this.food = food;
	            this.next = null;
	        }
	    }

	    // Add a food item to the linked list
	    public void addFood(Food food) {
	        Node newNode = new Node(food);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	        }
	    }

	    // List all foods
	    public void listFoods() {
	        System.out.println("============================================================================");
	        System.out.printf("%-20s %-20s %-10s %-10s%n", "Name", "Food Group", "Calories", "Daily percentage");
	        System.out.println("============================================================================");
	        
	        Node current = head;
	        while (current != null) {
	            current.food.display();
	            current = current.next;
	        }
	    }

	    // Find a food by name
	    public Food findFoodByName(String name) {
	        Node current = head;
	        while (current != null) {
	            if (current.food.name.equalsIgnoreCase(name)) {
	                return current.food;
	            }
	            current = current.next;
	        }
	        return null; // Not found
	    }

	    // Remove foods that have calories above a specified limit
	    public void removeHighCalorieFoods(int calorieLimit) {
	        Node current = head;
	        Node prev = null;

	        while (current != null) {
	            if (current.food.calories > calorieLimit) {
	                if (prev == null) { // Removing the head
	                    head = current.next;
	                } else {
	                    prev.next = current.next;
	                }
	            } else {
	                prev = current;
	            }
	            current = current.next;
	        }
	    }

	    // Get the size of the list (used for random selection)
	    public int size() {
	        int size = 0;
	        Node current = head;
	        while (current != null) {
	            size++;
	            current = current.next;
	        }
	        return size;
	    }

	    // Get the food at a specific index (for random selection)
	    public Food getFoodAt(int index) {
	        int currentIndex = 0;
	        Node current = head;
	        while (current != null) {
	            if (currentIndex == index) {
	                return current.food;
	            }
	            currentIndex++;
	            current = current.next;
	        }
	        return null; // Should never reach here if the index is valid
	    }
	}


