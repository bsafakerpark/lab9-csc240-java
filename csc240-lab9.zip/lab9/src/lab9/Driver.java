package lab9;
import java.io.*;
import java.util.*;

public class Driver {

	    @SuppressWarnings("resource")
		public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        FoodList foodList = new FoodList();
	      
	        // Read the foods from the file
	        try {
	            BufferedReader br = new BufferedReader(new FileReader("foods.txt"));
	            String line;
	            while ((line = br.readLine()) != null) {
	                // Split the line by whitespace
	                String[] parts = line.trim().split("\\s+");
	               
	                // Ensure the line has at least 4 elements before proceeding
	                if (parts.length >= 4) {
	                    String name = parts[0];
	                    String foodGroup = parts[1];
	                    int calories = Integer.parseInt(parts[2]);
	                    double dailyPercentage = Double.parseDouble(parts[3]);

	                    Food food = new Food(name, foodGroup, calories, dailyPercentage);
	                    foodList.addFood(food);
	                } else {
	                    // If the line does not have enough data, skip invalid line
	                    System.out.println("Skipping invalid line: " + line);
	                }
	            }
	            br.close();
	        } catch (IOException e) {
	            System.out.println("Error reading file: " + e.getMessage());
	            return; // or handle as appropriate
	        }
	       
	        // Main menu loop
	        boolean exit = false;
	        while (!exit) {
	            System.out.println("\n---------------------------------");
	            System.out.println("Welcome to Parkland Meal Selector");
	            System.out.println("---------------------------------");
	            System.out.println("Please select from the following");
	            System.out.println("1 - List food database");
	            System.out.println("2 - Create meal by manual selection");
	            System.out.println("3 - Create meal by random selection");
	            System.out.println("4 - Remove foods high in calorie");
	            System.out.println("5 - Exit");

	            int choice = scanner.nextInt();
	            scanner.nextLine(); // Consume the newline character

	            switch (choice) {
	                case 1:
	                    foodList.listFoods();
	                    break;

	                case 2:
	                    // Manual meal creation
	                    List<Food> selectedFoods = new ArrayList<>();
	                    for (int i = 0; i < 3; i++) {
	                        System.out.print("Enter food name: ");
	                        String foodName = scanner.nextLine();
	                        Food food = foodList.findFoodByName(foodName);
	                        if (food != null) {
	                            selectedFoods.add(food);
	                        } else {
	                            System.out.println("Food " + foodName + " not in database, try again");
	                            i--; // Retry the current food selection
	                        }
	                    }

	                    // Calculate the total calories and daily percentage
	                    int totalCalories = 0;
	                    double totalDailyPercentage = 0;
	                    for (Food food : selectedFoods) {
	                        totalCalories += food.calories;
	                        totalDailyPercentage += food.dailyPercentage;
	                    }

	                    System.out.println("===============================");
	                    System.out.println("Your selected meal");
	                    System.out.print("Foods: ");
	                    for (Food food : selectedFoods) {
	                        System.out.print(food.name + " ");
	                    }
	                    System.out.println();
	                    System.out.println("Total calorie count: " + totalCalories);
	                    System.out.println("Total daily percentage: " + (int)(totalDailyPercentage * 100) + "%");
	                    System.out.println("===============================");
	                    break;

	                case 3:
	                    // Random meal creation
	                    Random random = new Random();
	                    List<Food> randomFoods = new ArrayList<>();
	                    for (int i = 0; i < 3; i++) {
	                        int randomIndex = random.nextInt(foodList.size());
	                        Food randomFood = foodList.getFoodAt(randomIndex);
	                        randomFoods.add(randomFood);
	                    }

	                    // Calculate the total calories and daily percentage
	                    totalCalories = 0;
	                    totalDailyPercentage = 0;
	                    for (Food food : randomFoods) {
	                        totalCalories += food.calories;
	                        totalDailyPercentage += food.dailyPercentage;
	                    }

	                    System.out.println("===============================");
	                    System.out.println("Your selected meal");
	                    System.out.print("Foods: ");
	                    for (Food food : randomFoods) {
	                        System.out.print(food.name + " ");
	                    }
	                    System.out.println();
	                    System.out.println("Total calorie count: " + totalCalories);
	                    System.out.println("Total daily percentage: " + (int)(totalDailyPercentage * 100) + "%");
	                    System.out.println("===============================");
	                    break;

	                case 4:
	                    // Remove high calorie foods
	                    System.out.print("Enter calorie limit: ");
	                    int calorieLimit = scanner.nextInt();
	                    foodList.removeHighCalorieFoods(calorieLimit);
	                    break;

	                case 5:
	                    exit = true;
	                    break;

	                default:
	                    System.out.println("Invalid choice, try again.");
	            }
	        }

	        scanner.close();
	    }
	}



