package lab9;

public class Food {
	
	    String name;
	    String foodGroup;
	    int calories;
	    double dailyPercentage;

	    // Constructor
	    public Food(String name, String foodGroup, int calories, double dailyPercentage) {
	        this.name = name;
	        this.foodGroup = foodGroup;
	        this.calories = calories;
	        this.dailyPercentage = dailyPercentage;
	    }

	    // Method to see the food in formatted output
	    public void display() {
	        System.out.printf("%-20s %-20s %-10d %-10.2f%n", name, foodGroup, calories, dailyPercentage);
	    }
	}


